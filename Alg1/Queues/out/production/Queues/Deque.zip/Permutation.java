import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

public class Permutation {

    /*    private static void permDeq(String[] args) {
            if (args.length == 0) {
                return;
            }
            Deque<String> q = new Deque<>();
            for (String arg : args) {
                if (StdRandom.bernoulli()) {
                    q.addFirst(arg);
                } else {
                    q.addLast(arg);
                }
            }

            for (String str : q) {
                StdOut.println(q.removeFirst());
            }

        }
    */
/*    private static void permRandQueue(String[] args) {
        RandomizedQueue<String> q = new RandomizedQueue<>();
        for (String arg : args) {
            q.enqueue(arg);
        }

        for (String str : q) {
            StdOut.println(str);
        }

    }
*/
    public static void main(String[] args) {
        if (args.length == 0) {
            return;
        }
        // Permutation.permRandQueue(args);
        RandomizedQueue<String> q = new RandomizedQueue<>();
        int k = Integer.parseInt(args[0]);


        for (int i = 0; i < k; i++) {
            q.enqueue(StdIn.readString());
        }

        for (String str : q) {
            StdOut.println(str);
        }
    }
}
